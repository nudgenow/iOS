//
//  nudgecore_v2.h
//  nudgecore_v2
//
//  Created by Shubhasai Mohapatra on 11/06/24.
//

#import <Foundation/Foundation.h>

//! Project version number for nudgecore_v2.
FOUNDATION_EXPORT double nudgecore_v2VersionNumber;

//! Project version string for nudgecore_v2.
FOUNDATION_EXPORT const unsigned char nudgecore_v2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <nudgecore_v2/PublicHeader.h>


